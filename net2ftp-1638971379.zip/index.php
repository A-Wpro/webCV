<!doctype html>
<html lang="en">

<head>
        <title>Adam Wecker </title>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="description" content="Adam Wecker resume and CV" />
        <meta name="keywords" content="job, cv, AI, artificial, intelligence, artificial intelligence, engineer,  online cv, online resume,professional, professional resume, responsive, resume, vcard " />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        
        <!-- FAV AND ICONS   -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">
        <link rel="shortcut icon" href="assets/images/apple-icon.png">
        <link rel="shortcut icon" sizes="72x72" href="assets/images/apple-icon-72x72.png">
        <link rel="shortcut icon" sizes="114x114" href="assets/images/apple-icon-114x114.png">
        
        <!-- Google Font-->
        <link href="http://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="assets/icons/font-awesome-4.7.0/css/font-awesome.min.css">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="assets/plugins/css/bootstrap.min.css">
        <!-- Animate CSS-->
        <link rel="stylesheet" href="assets/plugins/css/animate.css">
        <!-- Owl Carousel CSS-->
        <link rel="stylesheet" href="assets/plugins/css/owl.css">
        <!-- Fancybox-->
        <link rel="stylesheet" href="assets/plugins/css/jquery.fancybox.min.css">
        <!-- Custom CSS-->
        <link rel="stylesheet" href="assets/css/styles.css">
        <link rel="stylesheet" href="assets/css/responsive.css">
        
        <!-- Colors -->
        <link rel="alternate stylesheet" href="assets/css/colors/blue.css" title="blue">
        <link rel="stylesheet" href="assets/css/colors/defauld.css" title="defauld">
        <link rel="alternate stylesheet" href="assets/css/colors/green.css" title="green">
        <link rel="alternate stylesheet" href="assets/css/colors/blue-munsell.css" title="blue-munsell">
        <link rel="alternate stylesheet" href="assets/css/colors/orange.css" title="orange">
        <link rel="alternate stylesheet" href="assets/css/colors/purple.css" title="purple">
        <link rel="alternate stylesheet" href="assets/css/colors/slate.css" title="slate">
        <link rel="alternate stylesheet" href="assets/css/colors/yellow.css" title="yellow">
    </head>
    <body class="dark-vertion black-bg">
        <!-- Start Loader -->
        <div class="section-loader">
            <div class="loader">
                <div></div>
                <div></div> 
            </div>
        </div>
        <!-- End Loader -->
        
        <!--
        ===================
           NAVIGATION
        ===================
        -->
        <header class="black-bg mh-header mh-fixed-nav nav-scroll mh-xs-mobile-nav wow fadeInUp" id="mh-header">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <nav class="navbar navbar-expand-lg mh-nav nav-btn">
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon icon"></span>
                        </button>
                    
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav mr-auto ml-auto">
                                <li class="nav-item active">
                                    <a class="nav-link" href="#mh-home">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#mh-about">About</a>
                                </li>
                                <li class="nav-item">
                                   <a class="nav-link" href="#mh-skills">Skills</a>
                                </li>                                
                                <li class="nav-item">
                                   <a class="nav-link" href="#mh-experience">Experiences</a>
                                </li>                                
                                <li class="nav-item">
                                    <a class="nav-link" href="#mh-portfolio">My recent projects</a>
                                </li>                               
                                <li class="nav-item">
                                   <a class="nav-link" href="#mh-contact">Contact</a>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </header>
        
        <!--
        ===================
            HOME 
        ===================
        -->
        <section class="mh-home" id="mh-home">
            <div class="home-ovimg">
                <div class="container">
                    <div class="row xs-column-reverse section-separator vertical-middle-content home-padding">
                        <div class="col-sm-6">
                            <div class="mh-header-info">
                                <div class="mh-promo wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                                    <span>Hello there, I'm</span>
                                </div>
                                
                                <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s">Adam Wecker</h2>
                                <h4 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s">Artificial Intelligence engineer / Data Scientist</h4>
                                <h3 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s" style='color: red' > Data Scientist at Total Energie until 06/2023 </h3>
                                <ul>
                                    <li class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.4s"><i class="fa fa-envelope"></i><a href="mailto:">adam.wecker0@gmail.com</a></li>
                                    <li class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.5s"><i class="fa fa-phone"></i><a href="callto:">+33 7 69 36 67 68</a></li>
                                    <li class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s"><i class="fa fa-map-marker"></i><address>Paris, France</address></li>
                                </ul>
                                
                                <ul class="social-icon wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.7s">
                                    <li><a href="#"><i class="www.linkedin.com/in/adam-wecker"></i></a></li>
                                    
                                    <li><a href="https://github.com/A-Wpro"><i class="fa fa-github"></i></a></li>
                                    
                                </ul>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="hero-img hm-home wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.6s">
                                <div class="img-border">
                                    <img src="assets/images/Wecker.jpg" alt=""  class="img-fluid"> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>   
        
        <!--
        ==================
            ABOUT
        =================
        -->
        <section class="mh-about" id="mh-about">
            <div class="container">
                <div class="row section-separator">
                    <div class="col-sm-12 col-md-6">
                        <div class="mh-about-img shadow-2 wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.4s">
                            <img src="assets/images/ab-img.png" alt="" class="img-fluid">
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <div class="mh-about-inner">
                            <h2 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">About Me</h2>
                            <p class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s">I am, Adam, an AI Engineer and developer based in Paris. I love programming, solving complex problems and team projects. I'm capable of using the tools, skills and languages below :</p>
                            <div class="mh-about-tag wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s">
                                <ul>
                                    <li><span>Python</span></li>
                                    <li><span>C/C++/C#</span></li>
                                    <li><span>Machine learning</span></li>
                                    <li><span>Deep Learning</span></li>
                                    <li><span>Reinforcement Learning</span></li>
                                    <li><span>Java</span></li>
                                    <li><span>Docker</span></li>
                                    <li><span>Scala</span></li>
                                    <li><span>SQL/noSQL database</span></li>
				    <li><span>AWS/Microsoft Azure/GCP</span></li>
                                    <li><span>php,CSS,HTML</span></li>
				    <li><span>JavaScript</span></li>
                                    <li><span>AI Algorithmic, Operational research</span></li>
                                    <li><span>Unity 3D</span></li>
                                    <li><span>Team works</span></li>
                                    <li><span>Learning news skills </span></li>
                                    <li><span>Many others </span></li>
                                    
                                </ul>
                                For more details look at my CV :
                            </div>
                            <a href="CV WECKER EN.pdf" class="btn btn-fill wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.4s">Download CV <i class="fa fa-download"></i></a>
                            <a href="CV WECKER.pdf" class="btn btn-fill wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.4s">Download CV (french version) <i class="fa fa-download"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        
        <!--
        ===================
           SKILLS
        ===================
        -->
        <section class="mh-skills" id="mh-skills">
            <div class="container">
                <div class="row section-separator">
                    <div class="section-title text-center col-sm-12">
                        <!--<h2>Skills</h2>-->
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <div class="mh-skills-inner">
                            <div class="mh-professional-skill wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s">
                                <h3>Technical Skills</h3>
                                <div class="each-skills">
                                    <div class="candidatos">
                                        <div class="parcial">
                                            <div class="info">
                                                <div class="nome">C/C++/C#</div>
                                                <div class="percentagem-num">75%</div>
                                            </div>
                                            <div class="progressBar">
                                                <div class="percentagem" style="width: 75%;"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="candidatos">
                                        <div class="parcial">
                                            <div class="info">
                                                <div class="nome">Python</div>
                                                <div class="percentagem-num">75%</div>
                                            </div>
                                            <div class="progressBar">
                                                <div class="percentagem" style="width: 75%;"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="candidatos">
                                        <div class="parcial">
                                            <div class="info">
                                                <div class="nome">Machine learning</div>
                                                <div class="percentagem-num">60%</div>
                                            </div>
                                            <div class="progressBar">
                                                <div class="percentagem" style="width: 60%;"></div>
                                            </div>
                                        </div>
                                    </div>
                                                                        <div class="candidatos">
                                        <div class="parcial">
                                            <div class="info">
                                                <div class="nome">Reinforcement learning</div>
                                                <div class="percentagem-num">60%</div>
                                            </div>
                                            <div class="progressBar">
                                                <div class="percentagem" style="width: 60%;"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="candidatos">
                                        <div class="parcial">
                                            <div class="info">
                                                <div class="nome">Deep Learning</div>
                                                <div class="percentagem-num">55%</div>
                                            </div>
                                            <div class="progressBar">
                                                <div class="percentagem" style="width: 55%;"></div>
                                            </div>
                                        </div>
                                    </div>
                                     <div class="candidatos">
                                        <div class="parcial">
                                            <div class="info">
                                                <div class="nome">SQL/noSQL</div>
                                                <div class="percentagem-num">36%</div>
                                            </div>
                                            <div class="progressBar">
                                                <div class="percentagem" style="width: 36%;"></div>
                                            </div>
                                        </div>
                                    </div> 
                                     <div class="candidatos">
                                        <div class="parcial">
                                            <div class="info">
                                                <div class="nome">Operational research</div>
                                                <div class="percentagem-num">33%</div>
                                            </div>
                                            <div class="progressBar">
                                                <div class="percentagem" style="width: 33%;"></div>
                                            </div>
                                        </div>
                                    </div> 
                                     <div class="candidatos">
                                        <div class="parcial">
                                            <div class="info">
                                                <div class="nome">Blockchains</div>
                                                <div class="percentagem-num">27%</div>
                                            </div>
                                            <div class="progressBar">
                                                <div class="percentagem" style="width: 27%;"></div>
                                            </div>
                                        </div>
                                    </div> 
                                    <div class="candidatos">
                                        <div class="parcial">
                                            <div class="info">
                                                <div class="nome">Js</div>
                                                <div class="percentagem-num">25%</div>
                                            </div>
                                            <div class="progressBar">
                                                <div class="percentagem" style="width: 25%;"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-6">
                        <div class="mh-professional-skills wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.5s">
                            <h3>Professional Skills</h3>
                            <ul class="mh-professional-progress" >
                                <li>
                                    <div class="mh-progress mh-progress-circle" data-progress="95"></div>
                                    <div class="pr-skill-name">Team Work</div>
                                </li>
                                <li>
                                    <div class="mh-progress mh-progress-circle" data-progress="60"></div> 
                                    <div class="pr-skill-name">Communication</div>
                                </li>
                                <li>
                                    <div class="mh-progress mh-progress-circle" data-progress="85"></div>
                                    <div class="pr-skill-name">Project Management</div>
                                </li> 
                                <li>
                                    <div class="mh-progress mh-progress-circle" data-progress="90"></div>
                                    <div class="pr-skill-name">Adaptability</div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <!--
        ===================
           EXPERIENCES
        ===================
        -->
        <section class="mh-experince" id="mh-experience">
            <div class="bolor-overlay">
                <div class="container">
                    <div class="row section-separator">
                        <div class="col-sm-12 col-md-6">
                            <div class="mh-education">
                                 <h3 class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s">Education</h3>
                                <div class="mh-education-deatils">
                                    <!-- Education Institutes-->
                                    <div class="mh-education-item dark-bg wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s">
                                        <h4>Engineering School <a href="https://www.esme.fr/">ESME SUDRIA</a></h4>
                                        <div class="mh-eduyear">2016 to 2021</div>
                                        <p>Founded in 1905, ESME Sudria is a private, non-profit higher education institution under the supervision of the French Ministry of Education and Research. The school has over a century of experience in training engineers. ESME Sudria is a proud member of the Grandes Ecoles, France's prestigious consortium of high-level engineering, whose students are selected through highly competitive entrance examinations.</p>
                                    </div>                                
                                    <!-- Education Institutes-->
                                    <div class="mh-education-item dark-bg wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.5s">
                                        <h4>Korean University <a href="https://en.knu.ac.kr/main/main.htm">Kyungpook National University</a></h4>
                                        <div class="mh-eduyear">2019-2019 ( 1 semester )</div>
                                        <p>KNU Ranked 1st Among Korean Universities, 119 Master's and 108 Ph.D programs. </p>
                                    </div>                                
                       
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-6">
                            <div class="mh-work">
                                 <h3>Work Experience</h3>
                                <div class="mh-experience-deatils">
                                                                        <!-- Work Experience-->
                                    <div class="mh-work-item dark-bg wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.4s">
                                            <h4>End of study internship <a href="https://astekgroup.fr/">Group Astek</a></h4>
                                        <div class="mh-eduyear">19/04/2021 to 16/10/2021</div>
                                        <span>Responsibility : </span>
                                        <ul class="work-responsibility">
                                            <li><i class="fa fa-circle"></i>Find a solution to visualize and map data (Confidential)</li>
                                        </ul>
                                    </div>    
   
                                    <!-- Work Experience-->
                                    <div class="mh-work-item dark-bg wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.4s">
                                        <h4>IT consultant <a href="https://nerytec.com/">Nerytec Consulting</a></h4>
                                        <div class="mh-eduyear">01/2020 to 03/2020</div>
                                        <span>Responsibility :</span>
                                        <ul class="work-responsibility">
                                            <li><i class="fa fa-circle"></i>Creating IT tools to improve efficiency</li>
                                            <li><i class="fa fa-circle"></i>Project Management</li>
                                        </ul>
                                    </div>   
                                                                 <!-- Work Experience-->
                                    <div class="mh-work-item dark-bg wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.4s">
                                        <h4>Student/part time job <a href="#">Grocery store and restaurant</a></h4>
                                        <div class="mh-eduyear">2013 to 03/2017</div>
                                        <span>Responsibility :</span>
                                        <ul class="work-responsibility">
                                            <li><i class="fa fa-circle"></i>Customer service</li>
                                            <li><i class="fa fa-circle"></i>Team work</li>
                                        </ul>
                                    </div> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <!--
        ===================
           Projects
        ===================
        -->
        <section class="mh-portfolio" id="mh-portfolio">
            <div class="container">
                <div class="row section-separator">
                    <div class="section-title col-sm-12 wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s">
                        <h3>Recent projects</h3> 
                        <a href="https://github.com/A-Wpro" class="btn btn-fill">My github for my most recent project</a>
                    </div>
                    <div class="part col-sm-12">
                        <div class="portfolio-nav col-sm-12" id="filter-button">
                            <ul>
                                <li data-filter="*" class="current wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.1s"> <span>All Categories</span></li>
                                <li data-filter=".AI" class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s"><span>Artificial intelligence</span></li>
                                <li data-filter=".prog" class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s"><span>Programing</span></li>
                                <li data-filter=".robot" class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.4s"><span>Robotics</span></li>
                                <li data-filter=".web" class="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.5s"><span>Web programing</span></li>
                            </ul>
                        </div>
                        <div class="mh-project-gallery col-sm-12 wow fadeInUp" id="project-gallery" data-wow-duration="0.8s" data-wow-delay="0.5s">
                            <div class="portfolioContainer row">
                                <div class="grid-item col-md-4 col-sm-6 col-xs-12 AI">
                                    <figure>
                                        <img src="assets/imageProjet/AICATDOG.png" alt="img04">
                                        <figcaption class="fig-caption">
                                            <i class="fa fa-search"></i>
                                            <h5 class="title">Cat/Dog recognition</h5>
                                            <span class="sub-title">AI cat dog CNN</span>
                                            <a data-fancybox data-src="#pj0"></a>
                                        </figcaption>
                                    </figure>
                                </div>
                                <div class="grid-item col-md-4 col-sm-6 col-xs-12 prog">
                                    <figure>
                                        <img src="assets/imageProjet/quantum.png" alt="img04">
                                        <figcaption class="fig-caption">
                                            <i class="fa fa-search"></i>
                                            <h5 class="title">QT creator based game, zelda like</h5>
                                            <span class="sub-title">C++ QT creator </span>
                                            <a href="assets/images/portfolio/g2.png" data-fancybox data-src="#pj1"></a>
                                        </figcaption>
                                    </figure>
                                </div>
                                <div class="grid-item col-md-4 col-sm-6 col-xs-12 prog">
                                    <figure>
                                        <img src="assets/imageProjet/webattackjpg.jpg" alt="img04">
                                        <figcaption class="fig-caption">
                                            <i class="fa fa-search"></i>
                                            <h5 class="title">Logs analysis using ML</h5>
                                            <span class="sub-title">Logs analysis using ML to predict attack on a network</span>
                                            <a href="assets/images/portfolio/g3.png" data-fancybox data-src="#pj2"></a>
                                        </figcaption>
                                    </figure>
                                </div>    
                                <div class="grid-item col-md-4 col-sm-6 col-xs-12 robot AI">
                                    <figure>
                                        <img src="assets/images/portfolio/g5.png" alt="img04">
                                        <figcaption class="fig-caption">
                                            <i class="fa fa-search"></i>
                                            <h5 class="title">Robotic hand that grab delicate items</h5>
                                            <span class="sub-title">AI robotic</span>
                                            <a href="assets/images/portfolio/g5.png" data-fancybox data-src="#pj3"></a>
                                        </figcaption>
                                    </figure>
                                </div>
                                <div class="grid-item col-md-4 col-sm-6 col-xs-12 web">
                                    <figure>
                                        <img src="assets/imageProjet/webtools.jpg" alt="img04">
                                        <figcaption class="fig-caption">
                                            <i class="fa fa-search"></i>
                                            <h5 class="title">Web tools for Head Hunter </h5>
                                            <span class="sub-title">Web tools </span>
                                            <a href="assets/images/portfolio/g4.png" data-fancybox data-src="#pj4"></a>
                                        </figcaption>
                                    </figure>
                                </div>
                                <div class="grid-item col-md-4 col-sm-6 col-xs-12 prog">
                                    <figure>
                                        <img src="assets/imageProjet/game2.PNG" alt="img04">
                                        <figcaption class="fig-caption">
                                            <i class="fa fa-search"></i>
                                            <h5 class="title">Basic games </h5>
                                            <span class="sub-title">C games</span>
                                            <a href="assets/imageProjet/p4.png" data-fancybox data-src="#pj5"></a>
                                        </figcaption>
                                    </figure>
                                </div>
                                <div class="grid-item col-md-4 col-sm-6 col-xs-12 prog">
                                    <figure>
                                        <img src="assets/imageProjet/sd_wan.png" alt="img04">
                                        <figcaption class="fig-caption">
                                            <i class="fa fa-search"></i>
                                            <h5 class="title">SD-WAN</h5>
                                            <span class="sub-title">RL agent for a better global network protocol</span>
                                            <a href="assets/images/portfolio/sd_wan.png" data-fancybox data-src="#pj6"></a>
                                        </figcaption>
                                    </figure>
                                </div>
                                    </div>
                                
                            </div> <!-- End: .grid .project-gallery -->
                        </div> <!-- End: .grid .project-gallery -->
                    </div> <!-- End: .part -->
                </div> <!-- End: .row -->
            </div>
            <!--
        ===================
           click on project
        ===================
        -->
            <div class="mh-portfolio-modal" id="pj0">
                <div class="container">
                    <div class="row mh-portfolio-modal-inner">
                        <div class="col-sm-5">
                            <h2>Cat/Dog Recognition</h2>
                            <p>This project is a usualy the first step in advanced AI programing. We aim to make an AI able to
                            recognise which animal is on a picture. I used a convolutional neural network architecture. Thanks to tensorflow
                            I easily used convolutional neural network, tensorflow is a powerful librarie for AI programing/
                            
                            </p>       
                            
                            <p>
                             
                            </p>
                                  
                            <div class="mh-about-tag">
                                <ul>
                                    <li><span>Python</span></li>
                                    <li><span>TensorFlow</span></li>
                                    <li><span>AI</span></li>
                                    <li><span>CNN</span></li>
                                    <li><span>Machine learning</span></li>
                                </ul>
                            </div>
                            
                        </div>
                        <div class="col-sm-7">
                            <div class="mh-portfolio-modal-img">
                                <img src="assets/imageProjet/catmeme.jpg" alt="" class="img-fluid">
                                <p>Example of a fail.</p>    
                                </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="pj1">
                <div class="container">
                    <div class="row mh-portfolio-modal-inner">
                        <div class="col-sm-5">
                            <h2>C++ QT openCV game </h2>
                            <p>We developed an RPG game on the MVC model using Qt framework.
                                The Game was developed using Qt 5.15 and opencv4 
                            </p>       
                            <p>
                             The source code is free on github.
                            </p>
                                  
                            <div class="mh-about-tag">
                                <ul>
                                    <li><span>C/C++</span></li>
                                    <li><span>QT</span></li>
                                    <li><span>Algorithm</span></li>
                   
                                </ul>
                            </div>
                            <a href="https://github.com/A-Wpro/ZeldaDungeonExplorer" class="btn btn-fill">Github link</a>
                        </div>
                        <div class="col-sm-7">
                            <div class="mh-portfolio-modal-img">
                                <img src="assets/imageProjet/github_video.jpg" alt="" class="img-fluid">
                                                     
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="pj2">
                <div class="container">
                    <div class="row mh-portfolio-modal-inner">
                        <div class="col-sm-5">
                            <h2>Logs Analysis</h2>
                            <p>Several log analysis of a date frame(~60GO) to train a model to predict attack</p>       
                            
                             <p>
                             The source code is free on github.
                            </p>     
                            <div class="mh-about-tag">
                                <ul>
                                    <li><span>Python</span></li>
                                    <li><span>AI</span></li>
                                    <li><span>Algorithm</span></li>
        
                                </ul>
                            </div>
                            <a href="#" class="btn btn-fill">Github link</a>
                        </div>
                        <div class="col-sm-7">
                            <div class="mh-portfolio-modal-img">
                                <img src="assets/imageProjet/AI.png" alt="" class="img-fluid">
                                <p>Ask me if you want a very complete report</p>    
                                     
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="pj4">
                <div class="container">
                    <div class="row mh-portfolio-modal-inner">
                        <div class="col-sm-5">
                            <h2>Web tool for rectuter </h2>
                            <p>During my 4th years I did a 3 months intership, my goal was to build a web site and a database for
                            Human Resources Director. They can : put into a database resume and CV of interesting people, put a automatic reminder
                            to reminde them to contact a candidat. They also have access to the database for statistic purpose.
                            </p>       
                            
                            <p>
                             The source code is free on github.
                            </p>     
                            <div class="mh-about-tag">
                                <ul>
                                    <li><span>php</span></li>
                                    <li><span>html</span></li>
                                    <li><span>css</span></li>
                                    <li><span>MySQL</span></li>
                                    <li><span>Project</span></li>
                                    <li><span>Intership 3 months</span></li>
                                    
                                </ul>
                            </div>
                            <a href="https://github.com/A-Wpro/cvReminderToolDB" class="btn btn-fill">Github link</a>
                        </div>
                        <div class="col-sm-7">
                            <div class="mh-portfolio-modal-img">
                                <img src="assets/imageProjet/Webtool1.png" alt="" class="img-fluid">
                                <p>User interface to add a CV in the database.</p>    
                                <img src="assets/imageProjet/Webtool2.png" alt="" class="img-fluid">
                                <p>Admin interface.</p>     
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="pj3">
                <div class="container">
                    <div class="row mh-portfolio-modal-inner">
                        <div class="col-sm-5">
                            <h2>Robotic hand that grab delicate items</h2>
                            <p>This project was a 5 students project, I have focus on bulding an AI able to understand what is the best 
                                pressure to grab a item without break it. I created an algorithm inspired by darwinian evolution theory.
                                Everytime a test is fail the algorithm modify the maximum or minimum pressure on the item.   
                            </p>       
                            
                                  
                            <div class="mh-about-tag">
                                <ul>
                                    <li><span>C</span></li>
                                    <li><span>json</span></li>
                                    <li><span>statistic</span></li>
                                    <li><span>AI</span></li>
                                    <li><span>Genetic algorithm</span></li>
                                    <li><span>programing</span></li>
                                    <li><span>Teamwork</span></li>
                                </ul>
                            </div>
                            
                        </div>
                        <div class="col-sm-7">
                            <div class="mh-portfolio-modal-img">
                                <img src="assets/imageProjet/geneticAlgo.png" alt="" class="img-fluid">
                                <p>A quick example of how genetic aglorithm works.</p>    
                                </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mh-portfolio-modal" id="pj5">
                <div class="container">
                    <div class="row mh-portfolio-modal-inner">
                        <div class="col-sm-5">
                            <h2>games</h2>
                            <p>During my scholarship I trained my programing skill on basic games like connect 4. Recentrly I have made with a team a Zelda like game</p>       
                            
                            
                            <div class="mh-about-tag">
                                <ul>
                                    <li><span>C/c++</span></li>
                                    <li><span>QT</span></li>
                                    <li><span>Graphic programing</span></li>
                                    <li><span>Game design</span></li>
                                    
                                   
                                </ul>
                            </div>
                            <a href="https://github.com/A-Wpro/RunnerGameIntialD" class="btn btn-fill">Github link</a>
                            <a href="https://github.com/A-Wpro/ZeldaDungeonExplorer" class="btn btn-fill">My Zelda game</a>
                        </div>
                        <div class="col-sm-7">
                            <div class="mh-portfolio-modal-img">
                                <img src="assets/imageProjet/p4.png" alt="" class="img-fluid">
                                <p>Interface of a game, white versus red.</p>    
                               </div>
                        </div>
                    </div>
                </div>
            </div>
                    <div class="mh-portfolio-modal" id="pj6">
                <div class="container">
                    <div class="row mh-portfolio-modal-inner">
                        <div class="col-sm-5">
                            <h2>SD-wan</h2>
                            <p>Virtualization and Software-Defined Networking (SDN) technologies are gradually gaining ground not only in data centers but also in WAN and RAN due to several key features mainly flexibility in scaling in and out the allocated resources and simplicity of configuration and troubleshooting. SDN applied to WAN enables management in a centralized manner and thus provides the ability to enhance application performance thanks to the global on-time knowledge of the network resources utilization and the demande requirement.</p>       
                            
                            
                            <div class="mh-about-tag">
                                <ul>
                                    <li><span>python</span></li>
                                    <li><span>AI</span></li>
                                    <li><span>Reinforcement Learning</span></li>
                                    <li><span>ONOS</span></li>
                                   
                                </ul>
                            </div>
                            <a href="https://github.com/A-Wpro/Project_ESME_2020_2021" class="btn btn-fill">Github link</a>
                            <a href="https://github.com/A-Wpro/SD_WAN_FASTAPI" class="btn btn-fill">API Github link</a>
                        </div>
                        <div class="col-sm-7">
                            <div class="mh-portfolio-modal-img">
                                <img src="assets/imageProjet/sd_wan.png" alt="" class="img-fluid">
                                <p>Our hand made poster.</p>    
                               </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </section>
        
        
        
        <!--
        ===================
           FOOTER 1
        ===================
        -->
        <footer class="mh-footer" id="mh-contact">
            <div class="map-image image-bg">
                <div class="container">
                    <div class="row section-separator">
                        <div class="col-sm-12 section-title wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s">
                            <h3>Contact</h3>
                        </div>
                        <div class="col-sm-12 mh-footer-address">
                            <div class="row">
                                <div class="col-sm-12 col-md-4">
                                    <div class="mh-address-footer-item dark-bg shadow-1 wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s">
                                        <div class="each-icon">
                                            <i class="fa fa-location-arrow"></i>
                                        </div>
                                        <div class="each-info">
                                            <h4>Address</h4>
                                            <address>
                                                Paris, 
                                                France                                            </address>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-4">
                                    <div class="mh-address-footer-item dark-bg shadow-1 wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.5s">
                                        <div class="each-icon">
                                            <i class="fa fa-envelope-o"></i>
                                        </div>
                                        <div class="each-info">
                                            <h4>Email</h4>
                                            <a href="mailto:adam.wecker0@gmail.com">adam.wecker0@gmail.com</a><br>
                                            
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-4">
                                    <div class="mh-address-footer-item dark-bg shadow-1 wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.7s">
                                        <div class="each-icon">
                                            <i class="fa fa-phone"></i>
                                        </div>
                                        <div class="each-info">
                                            <h4>Phone</h4>
                                            <a href="#">+33 7 69 36 67 68</a><br>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
  
                        <div class="col-sm-12 mh-copyright wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.3s">

                                <div class="col-sm-6">
                                    <ul class="social-icon">
                                        <li><a href="https://www.linkedin.com/in/adam-wecker/"><i class="fa fa-facebook"></i></a></li>
                                        
                                        <li><a href="https://github.com/A-Wpro"><i class="fa fa-github"></i></a></li>
                                        
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>     
    
    <!--
    ==============
    * JS Files *
    ==============
    -->
    
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    
    <!-- jQuery -->
    <script src="assets/plugins/js/jquery.min.js"></script>
    <!-- popper -->
    <script src="assets/plugins/js/popper.min.js"></script>
    <!-- bootstrap -->
    <script src="assets/plugins/js/bootstrap.min.js"></script>
    <!-- owl carousel -->
    <script src="assets/plugins/js/owl.carousel.js"></script>
    <!-- validator -->
    <script src="assets/plugins/js/validator.min.js"></script>
    <!-- wow -->
    <script src="assets/plugins/js/wow.min.js"></script>
    <!-- mixin js-->
    <script src="assets/plugins/js/jquery.mixitup.min.js"></script>
    <script src="assets/plugins/js/circle-progress.js"></script>
    <!-- jquery nav -->
    <script src="assets/plugins/js/jquery.nav.js"></script>
    <!-- Fancybox js-->
    <script src="assets/plugins/js/jquery.fancybox.min.js"></script>
    <!-- isotope js-->
    <script src="assets/plugins/js/isotope.pkgd.js"></script>
    <script src="assets/plugins/js/packery-mode.pkgd.js"></script>
   
   
    <!-- Custom Scripts-->
    <script src="assets/js/map-init.js"></script>
    <script src="assets/js/custom-scripts.js"></script>
    


        
</body>

</html><?php
		