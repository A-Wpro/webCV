<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Alimazon</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bitter:400,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css">
    <link rel="stylesheet" href="assets/css/Comment.css">
    <link rel="stylesheet" href="assets/css/Custom-File-Upload.css">
    <link rel="stylesheet" href="assets/css/Footer-Dark.css">
    <link rel="stylesheet" href="assets/css/Header-Dark.css">
    <link rel="stylesheet" href="assets/css/Lista-Productos-Canito.css">
    <link rel="stylesheet" href="assets/css/Login-Form-Dark.css">
    <link rel="stylesheet" href="assets/css/MUSA_carousel-product-cart-slider-1.css">
    <link rel="stylesheet" href="assets/css/MUSA_carousel-product-cart-slider.css">
    <link rel="stylesheet" href="assets/css/Pretty-Search-Form.css">
    <link rel="stylesheet" href="assets/css/MUSA_product-display-1.css">
    <link rel="stylesheet" href="assets/css/MUSA_product-display.css">
    <link rel="stylesheet" href="assets/css/Registration-Form-with-Photo.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body><div class="container">
	<div class="row">
        <h2>Les imprimantes</h2>
        
        <?php


$connect = mysqli_connect ("127.0.0.1","root","","Alimazon");
                if($connect){
                     
                        
                    $req = "SELECT libellé,Marque,quantité,prix,tva,description,Reference from produit where cat = 'Imprimante'";
                    $resultat = mysqli_query($connect, $req);
                    
                    
                
                    if ($resultat== false)  {echo 'erreur';}
                    else{
                        
                        $i=0;
                        while($ligne=mysqli_fetch_row($resultat)){
                             
                             
                              echo '            
           
      
        <div class="col-sm-3">
            <article class="col-item">
            	<div class="photo">
        			<div class="options-cart-round">
                                
        				<button class="btn btn-default" title="Add to cart">
        					<span class="fa fa-shopping-cart"></span>
        				</button>
        			</div>
        			<a href="#"> <img src="assets/img/i1.jpg"class="img-responsive" alt="Product Image" /> </a>
        		</div>
        		<div class="info">
        			<div class="row">
        				<div class="price-details col-md-6">
        					<p class="details">
        						';echo 'Marque : ';;echo $ligne[1];echo '
                                <a href="">Acheter</a>
                                <form action="CommentClient.php" >
                                 <input type="hidden" name="Refe" value="';echo $ligne[6];echo'"></input>
                                     
                                <button name="submit" class="btn btn-primary btn-block" type="submit">commenter </button></div>
                                </form>

                                
                                
                                
        					</p>
        					<h5>';echo $ligne[0];echo '</h5>
        					<span class="price-new">';echo ' prix : ';echo $ligne[3];echo '€';  ;echo '</span>
        				</div>
        			</div>
        		</div>
        	</article>
            <p class="text-center"></p>
        </div>

        	</article>
        </div>
	</div>
</div>
';


                              
                            
                        }
                        mysqli_close($connect);
                    }
                   
                    
                }
?>
     
    <div class="footer-dark">
        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-3 item">
                        <ul>
                            <li></li>
                            <li></li>
                            <li></li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-md-3 item">
                        <ul>
                            <li></li>
                            <li></li>
                            <li></li>
                        </ul>
                    </div>
                </div>
                <p class="copyright">666 rue de Gilles et John 66 660&nbsp;<br>Port-Vendres 06 33 33 33 33<br><br>Alimazon © 2025</p>
            </div>
        </footer>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/smart-forms.min.js"></script>
    <script src="assets/js/Custom-File-Upload.js"></script>
    <script src="assets/js/MUSA_product-display.js"></script>
</body>

</html>